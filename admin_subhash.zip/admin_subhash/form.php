<?php
include("header.php");
?>


<?php
include("config.php");
if(isset($_POST['submit']))
{
	$email=$_POST['email'];
	$password=$_POST['password'];

	$sql="insert into tbl_demo (email,password) value('$email','$password')";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		echo "<script>alert('record inserted')</script>";
	}

}

?>






	<!--//outer-wp-->
    <div class="outter-wp">
											<!--/sub-heard-part-->
											 <div class="sub-heard-part">
													   <ol class="breadcrumb m-b-0">
															<li><a href="index.html">Home</a></li>
															<li class="active">Forms</li>
														</ol>
											</div>	
											<!--/sub-heard-part-->	
												<!--/forms-->
													<div class="forms-main" style="margin-left:20%;">
														<h2 class="inner-tittle">Basic Form </h2>
															<div class="graph-form">
																	<div class="form-body">
																		<form method="post"> <div class="form-group">
                                                                             <label for="exampleInputEmail1">Email address</label> 
                                                                             <input type="email" class="form-control" name="email"id="exampleInputEmail1" placeholder="Email"> </div>
                                                                              <div class="form-group">
                                                                                 <label for="exampleInputPassword1">Password</label> 
                                                                                 <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password"> </div> 
                                                                              
                                                                                       <button type="submit" name="submit" class="btn btn-default">Submit</button> </form> 
																	</div>

														

</div>


<div class="graph-visual tables-main">
											<h2 class="inner-tittle">Basic Table</h2>
												<div class="graph">
														<div class="tables">
																
																<table class="table">
																	<thead>
																		<tr>
																		  <th>Email</th>
																		  <th>Password</th>
																		
																		</tr>
																	</thead>
																	<tbody>
																		<tr>
																		<?php
                                                include("config.php");
												$sql="select * from tbl_demo where status=0";
												$result=mysqli_query($con,$sql);
												while($row=mysqli_fetch_array($result))
												{
																		?>
																		<td><?php echo $row['email']; ?></td>
																		<td><?php echo $row['password']; ?></td>
												</tr>
												<?php
												}
												?>
																	</tbody>
																</table>
															</div>
												
										        </div>


<?php
include("footer.php");

include("sidebar.php");
?>
									
