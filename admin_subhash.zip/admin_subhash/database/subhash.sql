-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2023 at 12:47 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `subhash`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_demo`
--

CREATE TABLE `tbl_demo` (
  `id` int(5) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_demo`
--

INSERT INTO `tbl_demo` (`id`, `email`, `password`, `status`) VALUES
(1, 'abc@gmail.com', '', b'0'),
(2, 'abc@gmail.com', '12345', b'0'),
(3, 'subhash@gmail.com', 'paasdword', b'0'),
(4, 'subhash@gmail.com', 'paasdword', b'0'),
(5, 'subhash@gmail.com', 'paasdword', b'0'),
(6, '', 'fguysfgufgi', b'0'),
(7, '', 'h56yhhhhhhhhh', b'0'),
(8, '', 'fyfghfuytj ', b'0'),
(9, 'abc@gmail.com', '124', b'0'),
(10, 'subhash@gmail.com', '`1233', b'0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_demoname`
--

CREATE TABLE `tbl_demoname` (
  `id` int(5) NOT NULL,
  `cetegory` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_demoname`
--

INSERT INTO `tbl_demoname` (`id`, `cetegory`, `password`, `status`) VALUES
(1, 'fjhjrh546y5', 'fyfghfuytj ', b'0'),
(2, 'subhashbhai ', '`123457890--', b'0'),
(3, 'sarsvati', '456789045', b'0'),
(4, 'pariiiii', 'pari', b'0'),
(5, 'pariiiii', 'pari', b'0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_demo`
--
ALTER TABLE `tbl_demo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_demoname`
--
ALTER TABLE `tbl_demoname`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_demo`
--
ALTER TABLE `tbl_demo`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_demoname`
--
ALTER TABLE `tbl_demoname`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
